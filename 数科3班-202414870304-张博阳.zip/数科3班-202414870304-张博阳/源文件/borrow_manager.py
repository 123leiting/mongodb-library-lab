from mongodb_connect import MongoDBConnect

client = MongoDBConnect.getConnect()
db = client["library"]
coll = db["borrow_logs"]

# 借阅登记
def borrow_add(log_doc):
    res = coll.insert_one(log_doc)
    return res.inserted_id

# 归还图书（批量更新匹配记录）
def return_book(reader_card, book_isbn):
    res = coll.update_many(
        {"reader_card": reader_card, "book_isbn": book_isbn, "status": "借出"},
        {"$set": {"status": "已归还"}}
    )
    return res.modified_count

# 查询逾期记录
def query_overdue():
    return list(coll.find({"status": "逾期"}))

# 查询全部借阅记录
def query_all_borrow():
    return list(coll.find())

if __name__ == "__main__":
    print("borrow_manager模块加载成功")