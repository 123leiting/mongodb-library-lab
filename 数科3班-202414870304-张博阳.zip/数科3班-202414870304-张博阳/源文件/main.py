from book_manager import *
from reader_manager import *
from borrow_manager import *
from stat_manager import *
from mongodb_connect import MongoDBConnect
from datetime import datetime

if __name__ == "__main__":
    print("=====图书情报检索与统计平台=====")
    try:
        client = MongoDBConnect.getConnect()
        db = client["library"]
        print("✅ 数据库连接成功")
        cnt_book = db["books"].count_documents({})
        cnt_reader = db["readers"].count_documents({})
        cnt_borrow = db["borrow_logs"].count_documents({})
        print(f"📚 books集合总数：{cnt_book}")
        print(f"👤 readers集合总数：{cnt_reader}")
        print(f"📖 borrow_logs集合总数：{cnt_borrow}")
    except Exception as e:
        print("❌ 数据库连接失败", e)
        exit()

    while True:
        print("\n========菜单========")
        print("1.新增图书")
        print("2.条件检索图书")
        print("3.图书评分排行")
        print("4.修改图书信息")
        print("5.删除图书")
        print("6.借阅登记")
        print("7.图书归还")
        print("8.查询逾期借阅")
        print("9.图书分类统计（聚合）")
        print("10.借阅趋势统计")
        print("11.借阅畅销榜单")
        print("12.读者信息查询与统计")
        print("0.退出程序")
        opt = input("请输入功能编号：")

        if opt == "1":
            title = input("书名：")
            category = input("分类：")
            price = float(input("价格："))
            stock = int(input("库存："))
            rating = float(input("评分："))
            bid = add_book({"title":title,"category":category,"price":price,"stock":stock,"rating":rating})
            print(f"✅新增完成，受影响文档数：1，id：{bid}")

        elif opt == "2":
            cate = input("输入要检索的图书分类（直接回车查全部）：")
            if cate.strip() == "":
                res = find_books()
            else:
                res = find_books({"category": cate})
            if len(res) == 0:
                print("⚠️ 没有查到匹配图书")
            else:
                for item in res:
                    print(item)

        elif opt == "3":
            res = book_rating_rank()
            if len(res) == 0:
                print("⚠️ 暂无图书数据")
            else:
                for item in res:
                    print(item)

        elif opt == "4":
            title_key = input("输入要修改的图书书名：")
            new_price = float(input("输入新价格："))
            num = update_one_book({"title":title_key}, {"price":new_price})
            print(f"✅ 受影响文档数：{num}")

        elif opt == "5":
            title_key = input("输入要删除的图书书名：")
            num = delete_one_book({"title":title_key})
            print(f"✅ 受影响文档数：{num}")

        elif opt == "6":
            card = input("读者证号：")
            isbn = input("图书ISBN：")
            log = {
                "reader_card": card,
                "book_isbn": isbn,
                "borrow_date": datetime.now(),
                "status": "借出"
            }
            borrow_add(log)
            print("✅借阅登记成功，受影响文档数：1")

        elif opt == "7":
            card = input("读者证号：")
            isbn = input("图书ISBN：")
            num = return_book(card, isbn)
            print(f"✅ 受影响文档数：{num}")

        elif opt == "8":
            res = query_overdue()
            if len(res) == 0:
                print("⚠️ 暂无逾期记录")
            else:
                for item in res:
                    print(item)

        elif opt == "9":
            res = stat_book_by_category()
            if len(res) == 0:
                print("⚠️ 暂无图书分类数据")
            else:
                for item in res:
                    print(item)

        elif opt == "10":
            res = stat_borrow_by_year()
            if len(res) == 0:
                print("⚠️ 暂无借阅趋势数据")
            else:
                for item in res:
                    print(f"年份：{item['year']}，借阅量：{item['borrow_count']}")

        elif opt == "11":
            res = stat_top_borrow_book(3)
            if len(res) == 0:
                print("⚠️ 暂无借阅数据，无法生成畅销榜")
            else:
                for item in res:
                    print(f"ISBN:{item['_id']} 借阅次数：{item['borrow_times']}")

        elif opt == "12":
            res = find_readers()
            if len(res) == 0:
                print("⚠️ 没有读者信息")
            else:
                for r in res:
                    print(r)
            print("读者总数：", count_readers())
            print("学院列表：", get_distinct_college())

        elif opt == "0":
            print("👋 准备关闭数据库连接，程序退出")
            client.close()
            break
        else:
            print("❌输入无效，请重新选择！")