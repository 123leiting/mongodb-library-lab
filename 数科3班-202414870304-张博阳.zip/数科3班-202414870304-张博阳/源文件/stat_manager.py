from mongodb_connect import MongoDBConnect

client = MongoDBConnect.getConnect()
db = client["library"]
books_coll = db["books"]
borrow_coll = db["borrow_logs"]

# 图书分类统计
def stat_book_by_category():
    pipeline = [
        {
            "$group": {
                "_id": "$category",
                "book_count": {"$sum": 1},
                "total_stock": {"$sum": "$stock"},
                "avg_price": {"$avg": "$price"}
            }
        },
        {"$sort": {"total_stock": -1}}
    ]
    return list(books_coll.aggregate(pipeline))

# 借阅趋势，按年份统计
def stat_borrow_by_year():
    pipeline = [
        {
            "$group": {
                "_id": {"$year": "$borrow_date"},
                "borrow_count": {"$sum": 1}
            }
        },
        {"$project": {"year": "$_id", "borrow_count": 1, "_id": 0}}
    ]
    return list(borrow_coll.aggregate(pipeline))

# 畅销榜：借阅次数最多的图书
def stat_top_borrow_book(top_n=3):
    pipeline = [
        {"$group": {"_id": "$book_isbn", "borrow_times": {"$sum": 1}}},
        {"$sort": {"borrow_times": -1}},
        {"$limit": top_n}
    ]
    return list(borrow_coll.aggregate(pipeline))

if __name__ == "__main__":
    print("stat_manager模块加载成功")