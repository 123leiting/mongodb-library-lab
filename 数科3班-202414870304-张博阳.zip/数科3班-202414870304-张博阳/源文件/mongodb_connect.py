from pymongo import MongoClient

class MongoDBConnect:

    default_uri = "mongodb://libWriter:123456@127.0.0.1:27017/library"

    @staticmethod
    def getConnect(uri=default_uri):
        client = MongoClient(uri)
        return client


if __name__ == "__main__":
    try:
        cli = MongoDBConnect.getConnect()
        # 测试一下
        db = cli["library"]
        print("✅ 数据库连接成功！")
        cli.close()
    except Exception as e:
        print("❌ 连接失败：", e)
