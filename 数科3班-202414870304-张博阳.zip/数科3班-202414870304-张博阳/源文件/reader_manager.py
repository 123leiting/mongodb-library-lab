from mongodb_connect import MongoDBConnect

client = MongoDBConnect.getConnect()
db = client["library"]
coll = db["readers"]

# 查询读者
def find_readers(filter_dict=None):
    if filter_dict is None:
        filter_dict = {}
    return list(coll.find(filter_dict))

# 统计读者数量
def count_readers(filter_dict=None):
    if filter_dict is None:
        filter_dict = {}
    return coll.count_documents(filter_dict)

# 获取所有学院（去重distinct）
def get_distinct_college():
    return coll.distinct("college")

# 获取所有年级
def get_distinct_grade():
    return coll.distinct("grade")

if __name__ == "__main__":
    print("reader_manager模块加载成功")