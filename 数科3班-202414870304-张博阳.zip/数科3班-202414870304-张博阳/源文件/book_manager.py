from mongodb_connect import MongoDBConnect

client = MongoDBConnect.getConnect()
db = client["library"]
coll = db["books"]

# 新增单本图书
def add_book(book_doc):
    res = coll.insert_one(book_doc)
    return res.inserted_id

# 批量新增图书
def add_many_books(book_list):
    res = coll.insert_many(book_list)
    return res.inserted_ids

# 查询单本图书
def find_one_book(filter_dict):
    return coll.find_one(filter_dict)

# 条件检索图书
def find_books(filter_dict=None):
    if filter_dict is None:
        filter_dict = {}
    return list(coll.find(filter_dict))

# 修改一本图书
def update_one_book(filter_dict, new_data):
    res = coll.update_one(filter_dict, {"$set": new_data})
    return res.modified_count

# 删除单本
def delete_one_book(filter_dict):
    res = coll.delete_one(filter_dict)
    return res.deleted_count

# 批量删除
def delete_many_books(filter_dict):
    res = coll.delete_many(filter_dict)
    return res.deleted_count

# 评分排行（降序）
def book_rating_rank(limit_num=5):
    return list(coll.find().sort("rating", -1).limit(limit_num))

if __name__ == "__main__":
    print("book_manager模块加载成功")