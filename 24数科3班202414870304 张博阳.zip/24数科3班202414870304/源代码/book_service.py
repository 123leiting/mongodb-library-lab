# -*- coding: utf-8 -*-
"""图书业务：检索、统计、新增"""
from config import get_db


def query_by_category_price(category, min_price, max_price):
    """类别 + 价格区间组合筛选"""
    db = get_db()
    return list(db.books.find(
        {"category": category, "price": {"$gte": min_price, "$lte": max_price}},
        {"_id": 0, "isbn": 1, "title": 1, "price": 1, "stock": 1}
    ))


def query_by_tags_all(tags):
    """多标签同时匹配 $all"""
    db = get_db()
    return list(db.books.find({"tags": {"$all": tags}}, {"_id": 0, "title": 1, "tags": 1}))


def search_title(keyword):
    """书名模糊检索（中文用正则，text 索引不切分中文）"""
    db = get_db()
    return list(db.books.find({"title": {"$regex": keyword}}, {"_id": 0, "title": 1, "author": 1}))


def books_without_tags():
    """缺少 tags 字段的图书"""
    db = get_db()
    return list(db.books.find({"tags": {"$exists": False}}, {"_id": 0, "title": 1, "category": 1}))


def top_rated(limit=10):
    """评分最高的 N 本"""
    db = get_db()
    return list(db.books.find({}, {"_id": 0, "title": 1, "rating": 1})
                .sort("rating", -1).limit(limit))


def add_book(doc):
    """新增图书"""
    db = get_db()
    return db.books.insert_one(doc).inserted_id


def category_stat():
    """按类别统计藏书量、均价、均分"""
    db = get_db()
    return list(db.books.aggregate([
        {"$group": {"_id": "$category", "book_count": {"$sum": 1},
                    "avg_price": {"$avg": "$price"}, "avg_rating": {"$avg": "$rating"}}},
        {"$sort": {"book_count": -1}},
    ]))
