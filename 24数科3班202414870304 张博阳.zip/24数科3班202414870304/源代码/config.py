# -*- coding: utf-8 -*-
"""统一数据库连接模块：所有模块都从这里拿 db 对象。

连接优先级：
1. 环境变量 MONGO_URI（最优先，例如设置了带账号的连接串就用它）
2. 环境变量 MONGO_HOST + MONGO_PORT / MONGO_USER / MONGO_PASSWORD
3. 默认本机 mongodb://127.0.0.1:27017（不认证）
"""
import os
from pymongo import MongoClient
from pymongo.errors import OperationFailure, ServerSelectionTimeoutError

DB_NAME = os.environ.get("MONGO_DB", "smart_library")

HOST = os.environ.get("MONGO_HOST", "127.0.0.1")
PORT = os.environ.get("MONGO_PORT", "27017")

_client = None


def _build_candidates():
    """按优先级生成候选连接串；配置了账号的放前面"""
    cands = []
    env_uri = os.environ.get("MONGO_URI")
    if env_uri:
        cands.append(env_uri)

    user = os.environ.get("MONGO_USER")
    pwd = os.environ.get("MONGO_PASSWORD")
    if user and pwd:
        from urllib.parse import quote_plus
        cands.append("mongodb://%s:%s@%s:%s/?authSource=%s"
                     % (quote_plus(user), quote_plus(pwd), HOST, PORT,
                        os.environ.get("MONGO_AUTHDB", "admin")))

    cands.append("mongodb://%s:%s" % (HOST, PORT))
    return cands


def get_client():
    global _client
    if _client is not None:
        return _client

    last_err = None
    for uri in _build_candidates():
        c = None
        try:
            c = MongoClient(uri, serverSelectionTimeoutMS=3000)
            c.admin.command("ping")
            _client = c
            return _client
        except (ServerSelectionTimeoutError, OperationFailure) as e:
            last_err = e
            if c is not None:
                try:
                    c.close()
                except Exception:
                    pass

    raise RuntimeError(
        "无法连接 MongoDB（已尝试：%s）。请检查：\n"
        "  1) mongod 是否已启动（默认端口 27017）\n"
        "  2) 若启用了认证，请先设置环境变量 MONGO_USER / MONGO_PASSWORD\n"
        "  3) 或直接设置 MONGO_URI 指定完整连接串\n"
        "最后错误：%s" % ("，".join(_build_candidates()), last_err)
    )


def get_db():
    """返回数据库对象（单例，避免反复建连接）"""
    return get_client()[DB_NAME]


def collection_counts(db=None):
    """返回各集合文档数，程序启动时打印用"""
    if db is None:
        db = get_db()
    names = ["books", "readers", "borrow_logs", "audit_logs", "fs.files", "book_cat_stat"]
    result = {}
    for n in names:
        try:
            result[n] = db[n].count_documents({})
        except Exception:
            result[n] = -1
    return result


if __name__ == "__main__":
    db = get_db()
    print("数据库连接成功：", db.name)
    for k, v in collection_counts(db).items():
        print("  %-14s %d" % (k, v))
