# -*- coding: utf-8 -*-
"""菜单主程序"""
import os
from config import get_db, DB_NAME, collection_counts
from book_service import (query_by_category_price, query_by_tags_all, search_title,
                          books_without_tags, top_rated, add_book, category_stat)
from reader_service import find_reader, list_readers, add_reader, readers_without_fav
from borrow_service import (borrow_book, return_book, logs_by_reader,
                            college_top, monthly_trend, top_borrowed_books)
from gridfs_service import upload_file, download_file, list_files
from audit_service import get_recent_audit


def show_menu():
    print("\n========== 智慧图书馆数字资源平台 ==========")
    print(" 1. 图书：类别+价格区间筛选")
    print(" 2. 图书：多标签匹配($all)")
    print(" 3. 图书：书名模糊检索")
    print(" 4. 图书：评分TOP10")
    print(" 5. 图书：缺少tags字段的图书")
    print(" 6. 统计：按类别统计藏书量/均价/评分")
    print(" 7. 读者：按证号查询")
    print(" 8. 读者：缺少fav_categories的读者")
    print(" 9. 借阅：借书")
    print("10. 借阅：还书")
    print("11. 借阅：按读者查流水")
    print("12. 统计：学院借阅TOP5")
    print("13. 统计：按月借阅趋势")
    print("14. 统计：借阅最多10本图书")
    print("15. GridFS：上传电子书/封面")
    print("16. GridFS：下载并校验字节")
    print("17. GridFS：列出全部文件")
    print("18. 系统：查看最近审计日志")
    print(" 0. 退出")
    print("=" * 46)


def main():
    try:
        db = get_db()
    except RuntimeError as e:
        print(e)
        print("\n程序已退出：请先启动 MongoDB 服务（mongod）后重新运行。")
        return

    counts = collection_counts(db)
    print("连接数据库 %s 成功" % DB_NAME)
    print("各集合文档数：books=%d，readers=%d，borrow_logs=%d，audit_logs=%d，fs.files=%d，book_cat_stat=%d"
          % (counts["books"], counts["readers"], counts["borrow_logs"],
             counts["audit_logs"], counts["fs.files"], counts["book_cat_stat"]))
    if counts["books"] == 0:
        print("提示：当前数据库还没有数据，可先运行 python init_data.py 导入 books/readers/borrow_logs。")


    while True:
        show_menu()
        opt = input("请选择功能编号：").strip()

        try:
            if opt == "0":
                print("已退出")
                break

            elif opt == "1":
                cat = input("输入类别（计算机/文学/经济管理/数学/外语/历史）：").strip()
                lo = float(input("最低价格："))
                hi = float(input("最高价格："))
                r = query_by_category_price(cat, lo, hi)
                print("命中 %d 条：" % len(r))
                for x in r:
                    print("  %s | %s | %.2f 元 | 库存 %s" % (x["isbn"], x["title"], x["price"], x["stock"]))

            elif opt == "2":
                tags = [t.strip() for t in input("输入标签，用英文逗号分隔：").split(",") if t.strip()]
                r = query_by_tags_all(tags)
                print("命中 %d 条：" % len(r))
                for x in r:
                    print("  %s | 标签 %s" % (x["title"], x["tags"]))

            elif opt == "3":
                kw = input("书名关键词：").strip()
                r = search_title(kw)
                print("命中 %d 条：" % len(r))
                for x in r:
                    print("  %s | %s" % (x["title"], x["author"]))

            elif opt == "4":
                for x in top_rated(10):
                    print("  %.1f分 | %s" % (x["rating"], x["title"]))

            elif opt == "5":
                r = books_without_tags()
                print("缺少 tags 的图书 %d 条：" % len(r))
                for x in r:
                    print("  %s | %s" % (x["title"], x["category"]))

            elif opt == "6":
                for s in category_stat():
                    print("  %s | 藏书 %d 本 | 均价 %.2f | 均分 %.2f"
                          % (s["_id"], s["book_count"], s["avg_price"], s["avg_rating"]))

            elif opt == "7":
                card = input("读者证号（如 R20240001）：").strip()
                r = find_reader(card)
                print("  %s" % r if r else "  未找到该读者")

            elif opt == "8":
                r = readers_without_fav()
                print("缺少 fav_categories 的读者 %d 人：" % len(r))
                for x in r:
                    print("  %s | %s" % (x["card_no"], x["name"]))

            elif opt == "9":
                card = input("读者证号：").strip()
                isbn = input("图书ISBN：").strip()
                days = int(input("借阅天数（默认30）：") or 30)
                print(borrow_book(card, isbn, days))

            elif opt == "10":
                card = input("读者证号：").strip()
                isbn = input("图书ISBN：").strip()
                print(return_book(card, isbn))

            elif opt == "11":
                card = input("读者证号：").strip()
                r = logs_by_reader(card)
                print("最近 %d 条流水：" % len(r))
                for x in r:
                    print("  %s | 借 %s | 还 %s | %s"
                          % (x["book_isbn"], x["borrow_date"], x.get("return_date", "未归还"), x["status"]))

            elif opt == "12":
                for s in college_top():
                    print("  %s | 借阅 %d 次" % (s["_id"], s["borrow_total"]))

            elif opt == "13":
                r = monthly_trend()
                print("共 %d 个月份：" % len(r))
                for s in r:
                    print("  %d-%02d | %d 次" % (s["_id"]["year"], s["_id"]["month"], s["count"]))

            elif opt == "14":
                for x in top_borrowed_books():
                    loc = x.get("location") or {}
                    print("  %s | 借阅 %d 次 | %s-%s 在架 %s 本"
                          % (x["title"], x["borrow_cnt"], loc.get("floor", "-"),
                             loc.get("shelf", "-"), loc.get("copies", "-")))

            elif opt == "15":
                path = input("本地文件路径（可直接把文件拖进来）：").strip().strip('"')
                isbn = input("对应图书 ISBN（可空）：").strip()
                ftype = input("类型 pdf/png（回车自动识别）：").strip()
                if not os.path.exists(path):
                    print("文件不存在：%s" % path)
                else:
                    fid, msg = upload_file(path, isbn, ftype)
                    print(msg)

            elif opt == "16":
                name = input("GridFS 中的文件名（如 ebook_1.pdf）：").strip()
                save = input("保存到本地路径（可只填文件名）：").strip().strip('"')
                if not save:
                    save = os.path.basename(name)
                print(download_file(name, save)[1])

            elif opt == "17":
                r = list_files()
                print("共 %d 个文件：" % len(r))
                for f in r:
                    print("  %s | %d 字节 | %s | %s" %
                          (f.get("filename") or f.get("orig_name"), f["length"],
                           f["uploadDate"], f.get("isbn", "-")))

            elif opt == "18":
                for l in get_recent_audit(20):
                    print("  %s | %s | %s" % (l["operate_time"], l["operate_type"], l["detail"]))

            else:
                print("编号无效，请输入 0-18")

        except ValueError:
            print("输入格式错误：价格/天数需要填数字")
        except Exception as e:
            print("执行出错：%s" % e)


if __name__ == "__main__":
    main()
