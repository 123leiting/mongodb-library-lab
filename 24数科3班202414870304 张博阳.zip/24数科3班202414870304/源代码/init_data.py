# -*- coding: utf-8 -*-
"""一键初始化：导入 books / readers / borrow_logs，转换日期类型，建立索引。

用法：
    python init_data.py                # 默认读取脚本同目录下 data 文件夹
    python init_data.py D:\\我的数据    # 指定数据目录

数据目录中需要包含 books.txt、readers.txt、borrow_logs.txt，三个文件均为
JSON 数组（与课程学生包 03-数据 中的文件一致）。
"""
import io
import json
import os
import sys

from config import get_db
from pymongo import ASCENDING, DESCENDING, TEXT

DATE_FIELDS = {
    "books": ["publish_date"],
    "readers": ["register_date"],
    "borrow_logs": ["borrow_date", "return_date"],
}


def load_json_array(path):
    """读取 JSON 数组文件；兼容文件开头带 BOM 的情况"""
    with io.open(path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def to_date(value):
    """把字符串日期或 Extended JSON（{"$date": "..."}）转成 datetime；无法解析时原样返回"""
    from datetime import datetime
    if isinstance(value, dict) and "$date" in value:
        value = value["$date"]
    if not isinstance(value, str):
        return value
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d", "%Y/%m/%d", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(value[:19], fmt)
        except ValueError:
            continue
    return value


def import_collection(db, name, docs):
    if not docs:
        print("  %-12s 文件为空，跳过" % name)
        return 0
    fixed = []
    for d in docs:
        for fld in DATE_FIELDS.get(name, []):
            if fld in d:
                d[fld] = to_date(d[fld])
        fixed.append(d)
    db[name].delete_many({})
    result = db[name].insert_many(fixed)
    print("  %-12s 导入 %d 条" % (name, len(result.inserted_ids)))
    return len(fixed)


def build_indexes(db):
    db.books.create_index([("isbn", ASCENDING)], unique=True, name="isbn_1")
    db.books.create_index([("category", ASCENDING), ("price", ASCENDING)], name="category_1_price_1")
    db.books.create_index([("title", TEXT)], name="title_text")
    db.readers.create_index([("card_no", ASCENDING)], unique=True, name="card_no_1")
    db.borrow_logs.create_index([("reader_card", ASCENDING)], name="reader_card_1")
    db.borrow_logs.create_index([("book_isbn", ASCENDING)], name="book_isbn_1")
    db.borrow_logs.create_index([("borrow_date", ASCENDING)], name="borrow_date_1")
    db.audit_logs.create_index([("operate_time", DESCENDING)], name="operate_time_-1")
    print("  索引已建立：books 3 个、readers 1 个、borrow_logs 3 个、audit_logs 1 个")


def main():
    base = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "data")
    if not os.path.isdir(base):
        print("找不到数据目录：%s" % base)
        print("请把 books.txt、readers.txt、borrow_logs.txt 放进该目录，")
        print("或运行 python init_data.py 你的数据目录路径")
        return

    db = get_db()
    print("已连接数据库：%s" % db.name)
    total = 0
    for name in ("books", "readers", "borrow_logs"):
        path = os.path.join(base, name + ".txt")
        if not os.path.exists(path):
            print("  %-12s 缺少文件 %s，跳过" % (name, path))
            continue
        total += import_collection(db, name, load_json_array(path))

    build_indexes(db)

    print("\n导入完成，当前文档数：")
    for n in ("books", "readers", "borrow_logs"):
        print("  %-12s %d" % (n, db[n].count_documents({})))


if __name__ == "__main__":
    main()
