# -*- coding: utf-8 -*-
"""审计日志：所有写操作都要留痕"""
from datetime import datetime
from config import get_db


def write_audit_log(operator, operate_type, target_collection, target_id, detail):
    db = get_db()
    db.audit_logs.insert_one({
        "operate_time": datetime.now(),
        "operator": operator,
        "operate_type": operate_type,
        "target_collection": target_collection,
        "target_id": str(target_id),
        "detail": detail,
    })


def get_recent_audit(limit=100):
    db = get_db()
    return list(db.audit_logs.find({}, {"_id": 0}).sort("operate_time", -1).limit(limit))
