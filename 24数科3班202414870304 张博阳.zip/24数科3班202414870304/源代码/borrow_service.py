# -*- coding: utf-8 -*-
"""借阅业务：借书、还书、查询流水、统计"""
from datetime import datetime
from config import get_db
from audit_service import write_audit_log


def borrow_book(card_no, isbn, duration_days=30, operator="lib_admin"):
    """借书：校验库存 -> 扣库存 -> 写流水 -> 记审计
       不用多文档事务，用「先扣库存再写流水 + 失败回滚」的补偿方式"""
    db = get_db()
    book = db.books.find_one({"isbn": isbn})
    if not book:
        return "失败：图书不存在"
    if book.get("stock", 0) <= 0:
        return "失败：库存不足，当前库存 0"

    # 1) 扣库存（条件更新，避免并发超借）
    res = db.books.update_one({"isbn": isbn, "stock": {"$gt": 0}}, {"$inc": {"stock": -1}})
    if res.modified_count != 1:
        return "失败：库存已被他人借走"

    try:
        # 2) 写借阅流水
        log = {
            "reader_card": card_no,
            "book_isbn": isbn,
            "borrow_date": datetime.now(),
            "duration_days": duration_days,
            "status": "借出",
        }
        r = db.borrow_logs.insert_one(log)
        db.books.update_one({"isbn": isbn}, {"$inc": {"borrow_count": 1}})
    except Exception as e:
        # 3) 补偿：流水写失败要把库存加回去
        db.books.update_one({"isbn": isbn}, {"$inc": {"stock": 1}})
        return "失败：%s" % e

    write_audit_log(operator, "借书", "borrow_logs", r.inserted_id,
                    "读者 %s 借出 %s，期限 %d 天" % (card_no, isbn, duration_days))
    return "成功：已借出，流水号 %s" % r.inserted_id


def return_book(card_no, isbn, operator="lib_admin"):
    """还书：更新流水状态 -> 加库存"""
    db = get_db()
    log = db.borrow_logs.find_one(
        {"reader_card": card_no, "book_isbn": isbn, "status": {"$ne": "已归还"}},
        sort=[("borrow_date", -1)])
    if not log:
        return "失败：没有找到该读者未归还的这条借阅记录"

    db.borrow_logs.update_one({"_id": log["_id"]},
                              {"$set": {"status": "已归还", "return_date": datetime.now()}})
    db.books.update_one({"isbn": isbn}, {"$inc": {"stock": 1}})
    write_audit_log(operator, "还书", "borrow_logs", log["_id"], "读者 %s 归还 %s" % (card_no, isbn))
    return "成功：已归还"


def logs_by_reader(card_no, limit=20):
    db = get_db()
    return list(db.borrow_logs.find({"reader_card": card_no},
                                    {"_id": 0, "book_isbn": 1, "borrow_date": 1,
                                     "return_date": 1, "status": 1}).limit(limit))


def college_top(n=5):
    """各学院借阅量 TOP N：$lookup 关联 readers"""
    db = get_db()
    return list(db.borrow_logs.aggregate([
        {"$lookup": {"from": "readers", "localField": "reader_card",
                     "foreignField": "card_no", "as": "reader_info"}},
        {"$unwind": "$reader_info"},
        {"$group": {"_id": "$reader_info.college", "borrow_total": {"$sum": 1}}},
        {"$sort": {"borrow_total": -1}},
        {"$limit": n},
    ]))


def monthly_trend():
    """按月统计借阅趋势"""
    db = get_db()
    return list(db.borrow_logs.aggregate([
        {"$group": {"_id": {"year": {"$year": "$borrow_date"}, "month": {"$month": "$borrow_date"}},
                    "count": {"$sum": 1}}},
        {"$sort": {"_id.year": 1, "_id.month": 1}},
    ]))


def top_borrowed_books(n=10):
    """借阅最多的 N 本书，带馆藏位置"""
    db = get_db()
    return list(db.borrow_logs.aggregate([
        {"$group": {"_id": "$book_isbn", "borrow_cnt": {"$sum": 1}}},
        {"$sort": {"borrow_cnt": -1}},
        {"$limit": n},
        {"$lookup": {"from": "books", "localField": "_id", "foreignField": "isbn", "as": "book_info"}},
        {"$unwind": "$book_info"},
        {"$project": {"_id": 0, "isbn": "$_id", "borrow_cnt": 1,
                      "title": "$book_info.title", "location": "$book_info.location"}},
    ]))
