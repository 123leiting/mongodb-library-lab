# -*- coding: utf-8 -*-
"""读者业务"""
from config import get_db


def find_reader(card_no):
    db = get_db()
    return db.readers.find_one({"card_no": card_no}, {"_id": 0})


def list_readers(limit=30):
    db = get_db()
    return list(db.readers.find({}, {"_id": 0, "card_no": 1, "name": 1, "college": 1}).limit(limit))


def add_reader(doc):
    db = get_db()
    return db.readers.insert_one(doc).inserted_id


def readers_without_fav():
    """缺少 fav_categories 的读者"""
    db = get_db()
    return list(db.readers.find({"fav_categories": {"$exists": False}}, {"_id": 0, "card_no": 1, "name": 1}))
