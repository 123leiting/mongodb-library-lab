# -*- coding: utf-8 -*-
"""GridFS 电子书 / 封面图片存取，带字节校验"""
import os
import gridfs
from config import get_db
from audit_service import write_audit_log

TYPE_MAP = {".pdf": "pdf", ".png": "png", ".jpg": "jpg", ".jpeg": "jpg", ".txt": "txt"}


def upload_file(local_path, isbn="", file_type="", operator="lib_admin"):
    """上传：同时写入标准 filename 字段与自定义元数据，便于列表展示与按 isbn 查找"""
    if not os.path.exists(local_path):
        return None, "文件不存在：%s" % local_path

    db = get_db()
    fs = gridfs.GridFS(db)
    name = os.path.basename(local_path)
    if not file_type:
        file_type = TYPE_MAP.get(os.path.splitext(name)[1].lower(), "bin")
    size = os.path.getsize(local_path)

    with open(local_path, "rb") as f:
        fid = fs.put(f, filename=name, isbn=isbn, file_type=file_type, orig_name=name)

    write_audit_log(operator, "上传电子书", "fs.files", fid,
                    "上传 %s，%d 字节" % (name, size))
    return str(fid), "上传成功：%s（%d 字节），file_id = %s" % (name, size, fid)


def download_file(orig_name, save_path, operator="lib_admin"):
    """下载：按文件名找，读完比对字节数"""
    db = get_db()
    fs = gridfs.GridFS(db)
    doc = db.fs.files.find_one({"$or": [{"filename": orig_name}, {"orig_name": orig_name}]})
    if not doc:
        return None, "失败：GridFS 中没有名为 %s 的文件，请先用 17 号功能查看可用文件名" % orig_name

    data = fs.get(doc["_id"]).read()

    save_dir = os.path.dirname(os.path.abspath(save_path))
    if save_dir and not os.path.isdir(save_dir):
        os.makedirs(save_dir, exist_ok=True)

    with open(save_path, "wb") as out:
        out.write(data)

    expect = doc["length"]
    actual = os.path.getsize(save_path)
    ok = (expect == actual)
    write_audit_log(operator, "下载电子书", "fs.files", doc["_id"],
                    "下载 %s，校验 %s" % (orig_name, "通过" if ok else "失败"))
    return (expect, actual, ok), ("成功：%s，期望 %d 字节，实际 %d 字节，校验%s，已保存到 %s"
                                  % (orig_name, expect, actual, "通过" if ok else "失败", save_path))


def list_files():
    """列出 GridFS 全部文件"""
    db = get_db()
    return list(db.fs.files.find(
        {},
        {"filename": 1, "orig_name": 1, "length": 1, "uploadDate": 1, "isbn": 1, "file_type": 1}
    ).sort("uploadDate", -1))
